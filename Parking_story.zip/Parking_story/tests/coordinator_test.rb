require 'minitest/autorun'
require_relative '../parking_space'
require_relative '../attendant'
require_relative '../coordinator'
describe Coordinator do
    before do
        @parking_space_1 = ParkingSpace.new 1
        @honda_city = Object.new
        @attendant_1 = Attendant.new @parking_space_1
    end
    it 'ensures coordinator direct cars to his first attendants' do
        parking_space_2 = ParkingSpace.new 1
        attendant_2 = Attendant.new parking_space_2

        coordinator = Coordinator.new @attendant_1,attendant_2
        car_token = coordinator.direct @honda_city

        assert_equal(@honda_city.object_id, car_token)
    end
    
    it 'ensures coordinator directs car to his coordinator' do
        sub_coordinator = Coordinator.new @attendant_1
        
        coordinator = Coordinator.new sub_coordinator
        car_token = coordinator.direct(@honda_city)

        assert_equal(@honda_city.object_id, car_token)
    end

    it 'ensures coordinator directs car to his coordinators' do
        parking_space_2 = ParkingSpace.new 2
        attendant_2 = Attendant.new parking_space_2
        sub_coordinator_1 = Coordinator.new @attendant_1
        sub_coordinator_2 = Coordinator.new attendant_2

        coordinator = Coordinator.new sub_coordinator_1,sub_coordinator_2
        car_token = coordinator.direct(@honda_city)

        assert_equal(@honda_city.object_id, car_token)
    end

    it 'ensures coordinator directs car to his coordinators' do
        parking_space_2 = ParkingSpace.new 2    
        attendant_2 = Attendant.new parking_space_2
        sub_coordinator_1 = Coordinator.new @attendant_1
        sub_coordinator_2 = Coordinator.new attendant_2
        @parking_space_1.park Object.new

        coordinator = Coordinator.new sub_coordinator_1,sub_coordinator_2
        car_token = coordinator.direct(@honda_city)

        assert_equal(@honda_city.object_id, car_token)
    end

    it 'ensures coordinator directs car to his coordinators and attendants' do
        parking_space_2 = ParkingSpace.new 2      
        attendant_2 = Attendant.new parking_space_2
        sub_coordinator_1 = Coordinator.new @attendant_1
        @parking_space_1.park Object.new
        parking_space_2.park Object.new

        coordinator = Coordinator.new sub_coordinator_1,attendant_2
        car_token = coordinator.direct @honda_city

        assert_equal(@honda_city.object_id, car_token)
    end

    it 'ensures coordinator directs car to his coordinator who has subcoordinator' do
        parking_space_2 = ParkingSpace.new 2
        attendant_2 = Attendant.new parking_space_2
        sub_sub_coordinator = Coordinator.new @attendant_1,attendant_2
        sub_coordinator = Coordinator.new sub_sub_coordinator
        
        coordinator = Coordinator.new sub_coordinator
        car_token = coordinator.direct @honda_city
        
        assert_equal(@honda_city.object_id, car_token)
    end

    it 'raises exception PARKING FULL' do
        parking_space_2 = ParkingSpace.new 2
        attendant_2 = Attendant.new parking_space_2
        sub_coordinator_1 = Coordinator.new @attendant_1         
        @parking_space_1.park Object.new
        parking_space_2.park Object.new
        parking_space_2.park Object.new

        coordinator = Coordinator.new sub_coordinator_1,attendant_2
    
        assert_raises(RuntimeError) do
            coordinator.direct @honda_city
        end
    end

end