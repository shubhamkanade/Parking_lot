require_relative 'parking_staff'
class ParkingLot
    include Observer
    OCCUPANCY_PERCENT_80 = 80
    OCCUPANCY_PERCENT_100 = 100
    attr_reader :observers
    def initialize *parking_spaces
        @observers = []
        @parking_spaces = parking_spaces
        @parking_spaces.each { |parking_space| parking_space.add_observer(self) }
        @occupancy = {}
        @parking_spaces.each{ |parking_space| @occupancy.merge!(parking_space => 0) }
        @_80_percent_occupancy_already_notified = false
        @total_percent_occupancy = 0
    end

    def update_on_park parking_space
        calculate_occupancy parking_space
        check_occupancy
    end

    def update_on_unpark(parking_space)
        calculate_occupancy parking_space
        if @total_percent_occupancy < OCCUPANCY_PERCENT_80
            @_80_percent_occupancy_already_notified = false
        end
        check_occupancy
    end

    def check_occupancy
        is_80_percent_occupancy?
        is_100_percent_occupancy?
    end

    def calculate_occupancy parking_space
        occupied_slots = parking_space.occupied
        total_slots = parking_space.slots
        occupied_percentage = occupied_slots * 100 / total_slots
        @occupancy[parking_space] = occupied_percentage
        @total_percent_occupancy = @occupancy.values.inject { |a, b| a + b } / @occupancy.size
    end

    def is_80_percent_occupancy?
        if @total_percent_occupancy >= OCCUPANCY_PERCENT_80 &&  !@_80_percent_occupancy_already_notified
            notify_on_80_percent_occupancy
            @_80_percent_occupancy_already_notified = true
        end
    end

    def is_100_percent_occupancy?
        notify_on_space_full self if @total_percent_occupancy == OCCUPANCY_PERCENT_100 
    end

    def notify_on_80_percent_occupancy
        @observers.each do |observer|
            observer.update_on_80_percent_occupancy(self)
        end
    end

end